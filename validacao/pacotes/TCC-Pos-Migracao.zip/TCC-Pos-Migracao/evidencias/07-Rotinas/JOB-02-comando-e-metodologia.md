# JOB-02 — Atualização de multas

Execução final: 17/10/2026, concluída às 20:10:01, America/Sao_Paulo.
Resultado: **20 testes executados; 0 falhas; 0 erros; 0 ignorados. BUILD SUCCESS.**

## Comando acionado no PowerShell

```powershell
& "C:\Users\Rhuan Elias\Documents\Codex\2026-10-14\vocye-que-conhece-4\work\executar-job-controlado.ps1"
```

## Comando Maven executado pelo script

Diretório de execução: `C:\Users\Rhuan Elias\Documents\Codex\2026-10-14\vocye-que-conhece-4\work\pos-migracao-ensaios`, cópia isolada dos fontes do microsserviço para ensaio.

```powershell
$env:JAVA_HOME = 'C:\Program Files\Java\jdk-21'
.\mvnw.cmd -o test '-Dtest=AtualizacaoMultasIntegrationTest' '-DargLine=' '-Dquarkus.http.test-port=0' '-Dquarkus.http.port=0'
```

- `mvnw.cmd`: Maven Wrapper do projeto.
- `-o`: execução offline do Maven, usando dependências previamente disponíveis. Não significa ausência de comunicação local com Docker ou servidores de teste.
- `test`: executa a fase de testes.
- `-Dtest=AtualizacaoMultasIntegrationTest`: seleciona a classe de testes integrados da atualização de multas.
- `-DargLine=`: define como vazio o argumento adicional da JVM de testes.
- `-Dquarkus.http.test-port=0` e `-Dquarkus.http.port=0`: selecionam portas HTTP automaticamente, evitando conflito com o microsserviço publicado em 8081.

## Método e alcance

O ensaio utilizou Java 21, Quarkus em perfil de teste, PostgreSQL 14 temporário criado por Testcontainers e respostas de integrações simuladas com WireMock. O banco da aplicação em uso não foi o destino do ensaio. O perfil de teste configurou a expressão `0/1 * * * * ?`, com agendador inicialmente pausado e retomado nos testes pertinentes. Essa configuração pertence ao ensaio e não altera o agendamento da aplicação publicada.

A classe verificou recálculo e persistência das multas, consulta do tipo atual de usuário, repetição sem acumulação indevida, preservação diante de falhas simuladas, proteção de devoluções e execução pelo agendador. O cenário de massa mista verificou os valores 20,00; 5,00; 10,00; 0,00; 19,50; 7,00; 0,00. O teste `agendadorRealDisparaConsultaEAtualizaBanco` verificou a atualização pelo agendador sem invocação manual da rotina.

Os avisos de falhas presentes no log fazem parte dos cenários de erro simulado. O relatório final confirma ausência de falhas ou erros nos testes. A evidência comprova os cenários em ambiente controlado; não comprova observação do disparo à meia-noite na aplicação publicada nem integração com os serviços reais nesse ensaio.

## Texto para o TCC

Para verificar a rotina de atualização de multas após a migração, executou-se a classe `AtualizacaoMultasIntegrationTest` por meio do Maven Wrapper, em ambiente de teste isolado. Utilizou-se PostgreSQL temporário provisionado por Testcontainers e simulação das integrações externas com WireMock. O agendamento foi acelerado para intervalos de um segundo nos testes pertinentes, permitindo verificar o disparo da rotina e a persistência dos resultados sem aguardar o horário de produção. Foram concluídos 20 testes, sem falhas, erros ou casos ignorados. Essa validação corresponde a uma execução controlada, não à observação do disparo à meia-noite na aplicação publicada.

## Evidências neste pacote

- `JOB-02-resultado.txt`: relatório original Surefire com os 20 testes aprovados.
- `../rastreabilidade.json`: resultados, arquivos e hashes SHA-256.

Os logs completos, XML e tentativas anteriores foram preservados fora deste pacote, na pasta Historico-TCC-Pos-Migracao-Completo.
